import java.awt.*;

class FilterTest2Frame extends Frame {
    private FilterTest2 m_filterTest;

    public FilterTest2Frame ( String str ) {
	super ( str );
    }

    public void Setup ( FilterTest2 ft2 ) {
	m_filterTest = ft2;
    }
}

