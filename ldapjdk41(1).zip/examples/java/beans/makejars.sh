#!/bin/sh

jar cvfm LDAPSimpleAuth.jar netscape/ldap/beans/LDAPSimpleAuth.mf netscape/ldap/beans/LDAPSimpleAuth*.class netscape/ldap/beans/LDAPBasePropertySupport.class

jar cvfm LDAPGetProperty.jar netscape/ldap/beans/LDAPGetProperty.mf netscape/ldap/beans/LDAPGetProperty*.class netscape/ldap/beans/LDAPBasePropertySupport.class

jar cvfm LDAPGetEntries.jar netscape/ldap/beans/LDAPGetEntries.mf netscape/ldap/beans/LDAPGetEntries*.class netscape/ldap/beans/LDAPBasePropertySupport.class

jar cvfm LDAPIsMember.jar netscape/ldap/beans/LDAPIsMember.mf netscape/ldap/beans/LDAPIsMember*.class netscape/ldap/beans/LDAPBasePropertySupport.class

jar cvfm DisplayString.jar netscape/ldap/beans/DisplayString.mf netscape/ldap/beans/DisplayString*.class
